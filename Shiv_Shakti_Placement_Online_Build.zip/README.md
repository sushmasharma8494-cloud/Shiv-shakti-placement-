# Shiv Shakti Placement — Firebase Authentication + Firestore

This Android project is connected to the Firebase project using `app/google-services.json`.

## Connected features
- Candidate registration with Firebase Authentication (email + password)
- Company registration with Firebase Authentication (email + password)
- Login for candidate/company/admin
- User role saved in Firestore: `users/{uid}`
- Candidate profile saved in `candidates/{uid}`
- Company profile saved in `companies/{uid}`
- Existing Firebase session is restored when the app opens
- Logout signs out from Firebase
- Admin is **not** available through public registration; an admin account must be provisioned/trusted separately and have `role: "admin"` in Firestore.

## Before first login
In Firebase Console, enable:
1. Authentication → Sign-in method → Email/Password
2. Firestore Database → Create database

The app expects these collections:
- `users`
- `candidates`
- `companies`

## Important
The app currently uses email/password authentication. The original Mobile / Email field was changed to Email so Firebase Authentication is used correctly.

For production, add and test Firestore Security Rules, email verification/password reset, phone OTP if needed, resume storage, job posting/approval, applications, and server-controlled admin claims.
