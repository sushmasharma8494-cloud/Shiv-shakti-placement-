package com.shivshakti.placement

import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShivShaktiApp() }
    }
}

@Composable
fun ShivShaktiApp() {
    val nav = rememberNavController()
    val auth = remember { FirebaseAuth.getInstance() }
    val start = if (auth.currentUser != null) "session" else "role"

    NavHost(nav, startDestination = start) {
        composable("session") { SessionScreen(nav) }
        composable("role") { RoleScreen(nav) }
        composable("login/{role}") { LoginScreen(nav, it.arguments?.getString("role") ?: "candidate") }
        composable("register/{role}") { RegisterScreen(nav, it.arguments?.getString("role") ?: "candidate") }
        composable("candidate") { CandidateDashboard(nav) }
        composable("company") { CompanyDashboard(nav) }
        composable("admin") { AdminDashboard(nav) }
    }
}

@Composable
fun SessionScreen(nav: NavHostController) {
    val uid = FirebaseAuth.getInstance().currentUser?.uid
    var loading by remember { mutableStateOf(true) }
    var role by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(uid) {
        if (uid == null) {
            nav.navigate("role") { popUpTo("session") { inclusive = true } }
            return@LaunchedEffect
        }
        FirebaseFirestore.getInstance().collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                role = doc.getString("role")
                loading = false
                when (role) {
                    "candidate" -> nav.navigate("candidate") { popUpTo("session") { inclusive = true } }
                    "company" -> nav.navigate("company") { popUpTo("session") { inclusive = true } }
                    "admin" -> nav.navigate("admin") { popUpTo("session") { inclusive = true } }
                    else -> {
                        FirebaseAuth.getInstance().signOut()
                        error = "Account role is not configured."
                    }
                }
            }
            .addOnFailureListener {
                loading = false
                error = "Could not load your account. Please try again."
            }
    }

    Page("Shiv Shakti Placement", "Checking your account...") {
        if (loading) CircularProgressIndicator()
        if (error.isNotEmpty()) {
            Text(error, color = MaterialTheme.colorScheme.error)
            Button({ nav.navigate("role") { popUpTo("session") { inclusive = true } } }, Modifier.fillMaxWidth()) { Text("Continue") }
        }
    }
}

@Composable
fun RoleScreen(nav: NavHostController) {
    Page("Shiv Shakti Placement", "Login / Register as") {
        Button({ nav.navigate("login/candidate") }, Modifier.fillMaxWidth()) { Text("Candidate Login") }
        Button({ nav.navigate("register/candidate") }, Modifier.fillMaxWidth()) { Text("Candidate Registration") }
        Button({ nav.navigate("login/company") }, Modifier.fillMaxWidth()) { Text("Company Login") }
        Button({ nav.navigate("register/company") }, Modifier.fillMaxWidth()) { Text("Company Registration") }
        OutlinedButton({ nav.navigate("login/admin") }, Modifier.fillMaxWidth()) { Text("Admin Login") }
    }
}

@Composable
fun LoginScreen(nav: NavHostController, role: String) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    Page("${role.replaceFirstChar { it.uppercase() }} Login", "Use your registered email and password") {
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, { password = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation())

        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)

        Button({
            error = ""
            if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
                error = "Please enter a valid email."
                return@Button
            }
            if (password.length < 6) {
                error = "Password must be at least 6 characters."
                return@Button
            }
            loading = true
            auth.signInWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid
                    if (uid == null) {
                        loading = false
                        error = "Login failed."
                        return@addOnSuccessListener
                    }
                    db.collection("users").document(uid).get()
                        .addOnSuccessListener { doc ->
                            loading = false
                            val savedRole = doc.getString("role")
                            if (savedRole != role) {
                                auth.signOut()
                                error = "This account is not registered as $role."
                            } else {
                                val destination = when (role) {
                                    "candidate" -> "candidate"
                                    "company" -> "company"
                                    else -> "admin"
                                }
                                nav.navigate(destination) { popUpTo("role") { inclusive = true } }
                            }
                        }
                        .addOnFailureListener {
                            loading = false
                            auth.signOut()
                            error = "Account details could not be loaded."
                        }
                }
                .addOnFailureListener {
                    loading = false
                    error = "Login failed. Check email/password."
                }
        }, Modifier.fillMaxWidth(), enabled = !loading) { Text(if (loading) "Logging in..." else "Login") }

        if (role != "admin") {
            TextButton({ nav.navigate("register/$role") }, enabled = !loading) { Text("Create new account") }
        }
    }
}

@Composable
fun RegisterScreen(nav: NavHostController, role: String) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var qualification by remember { mutableStateOf("") }
    var experience by remember { mutableStateOf("") }
    var companyName by remember { mutableStateOf("") }
    var contactPerson by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    Page("${role.replaceFirstChar { it.uppercase() }} Registration", "Create your Shiv Shakti Placement account") {
        if (role == "candidate") {
            TextFieldState("Full Name", name) { name = it }
            TextFieldState("Mobile Number", phone) { phone = it }
            TextFieldState("Email", email) { email = it }
            TextFieldState("Qualification", qualification) { qualification = it }
            TextFieldState("Experience", experience) { experience = it }
        } else {
            TextFieldState("Company Name", companyName) { companyName = it }
            TextFieldState("Contact Person", contactPerson) { contactPerson = it }
            TextFieldState("Mobile Number", phone) { phone = it }
            TextFieldState("Email", email) { email = it }
            TextFieldState("Company Address", address) { address = it }
        }
        OutlinedTextField(password, { password = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation())

        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)

        Button({
            error = ""
            if (email.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
                error = "Please enter a valid email."
                return@Button
            }
            if (password.length < 6) {
                error = "Password must be at least 6 characters."
                return@Button
            }
            if (phone.isBlank()) {
                error = "Please enter mobile number."
                return@Button
            }
            if (role == "candidate" && name.isBlank()) {
                error = "Please enter your name."
                return@Button
            }
            if (role == "company" && companyName.isBlank()) {
                error = "Please enter company name."
                return@Button
            }

            loading = true
            auth.createUserWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid
                    if (uid == null) {
                        loading = false
                        error = "Registration failed."
                        return@addOnSuccessListener
                    }

                    val userData = hashMapOf(
                        "name" to if (role == "candidate") name.trim() else contactPerson.trim(),
                        "email" to email.trim(),
                        "phone" to phone.trim(),
                        "role" to role
                    )
                    val profileData = if (role == "candidate") {
                        hashMapOf(
                            "name" to name.trim(), "phone" to phone.trim(), "email" to email.trim(),
                            "qualification" to qualification.trim(), "experience" to experience.trim()
                        )
                    } else {
                        hashMapOf(
                            "companyName" to companyName.trim(), "contactPerson" to contactPerson.trim(),
                            "phone" to phone.trim(), "email" to email.trim(), "address" to address.trim()
                        )
                    }

                    db.collection("users").document(uid).set(userData)
                        .addOnSuccessListener {
                            val collection = if (role == "candidate") "candidates" else "companies"
                            db.collection(collection).document(uid).set(profileData)
                                .addOnSuccessListener {
                                    loading = false
                                    val destination = if (role == "candidate") "candidate" else "company"
                                    nav.navigate(destination) { popUpTo("role") { inclusive = true } }
                                }
                                .addOnFailureListener {
                                    loading = false
                                    error = "Account created, but profile could not be saved."
                                }
                        }
                        .addOnFailureListener {
                            loading = false
                            error = "Account created, but account details could not be saved."
                        }
                }
                .addOnFailureListener {
                    loading = false
                    error = "Registration failed. Email may already be registered."
                }
        }, Modifier.fillMaxWidth(), enabled = !loading) { Text(if (loading) "Creating account..." else "Register") }

        TextButton({ nav.navigate("login/$role") }, enabled = !loading) { Text("Already have an account? Login") }
    }
}

@Composable
fun CandidateDashboard(nav: NavHostController) = DashboardPage(nav, "Candidate Dashboard", "Jobs, applications and profile", listOf(
    "Browse Jobs", "Apply for Jobs", "My Applications", "My Profile"
))

@Composable
fun CompanyDashboard(nav: NavHostController) = DashboardPage(nav, "Company Dashboard", "Post requirements and manage candidates", listOf(
    "Post Job Requirement", "View Candidates", "Shortlist Candidates", "Manage Requirements"
))

@Composable
fun AdminDashboard(nav: NavHostController) = DashboardPage(nav, "Admin Dashboard", "Placement management", listOf(
    "Manage Candidates", "Manage Companies", "Approve Jobs", "View Applications", "Placement Reports"
))

@Composable
fun DashboardPage(nav: NavHostController, title: String, subtitle: String, items: List<String>) {
    Page(title, subtitle) {
        items.forEach { Text("• $it") }
        Button({
            FirebaseAuth.getInstance().signOut()
            nav.navigate("role") { popUpTo(0) }
        }, Modifier.fillMaxWidth()) { Text("Logout") }
    }
}

@Composable
fun TextFieldState(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(value, onValueChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
}

@Composable
fun Page(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Text(subtitle, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(8.dp))
        content()
    }
}
